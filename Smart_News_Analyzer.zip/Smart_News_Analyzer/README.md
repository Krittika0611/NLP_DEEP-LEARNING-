# Smart Newz Analyzer — NLP + Deep Learning Mini Project

A beginner-friendly Flask web application that predicts:
- **News category:** Sports, Politics, Technology, Business
- **Sentiment:** Positive, Negative, Neutral
- **Keywords:** high-weight words/bigrams from the article

## Requirements
- Python 3.10 or newer
- VS Code
- Internet is only needed to install packages (the app itself runs locally)

## Run in VS Code (Windows)

1. Extract `Smart_News_Analyzer.zip`.
2. Open the extracted `Smart_News_Analyzer` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run this instead:

   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe app.py
   ```

5. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

6. Start the app:

   ```powershell
   python app.py
   ```

7. Open the local address printed in the terminal, usually **http://127.0.0.1:5000**.

The app trains its TF-IDF + Logistic Regression baseline models automatically the first time and saves them in `news_models.joblib`.

## Included NLP concepts
- Text normalization (lowercase, URL/punctuation removal)
- TF-IDF vectorization
- Unigrams and bigrams
- Text classification
- Keyword extraction
- Accuracy, precision, recall and F1-score evaluation

## Included Deep Learning experiment (optional)
The web app uses a lightweight TF-IDF + Logistic Regression baseline so it starts quickly on a typical laptop. To run the syllabus-aligned LSTM experiment:

```powershell
python -m pip install -r requirements-dl.txt
python train_lstm.py
```

TensorFlow is a large dependency and may take a while to install. The script trains separate LSTM models for category and sentiment, evaluates them, and saves `.keras` files.

## Evaluate the baseline models

```powershell
python train_evaluate.py
```

## Dataset
`data/news_dataset.csv` is a small, hand-written educational sample dataset with 96 examples across four categories and three sentiment labels. It is intended to demonstrate the workflow, not produce reliable real-world predictions. A small dataset can produce misleading confidence scores and weak generalization.

## Project structure

```text
Smart_News_Analyzer/
├── app.py
├── train_evaluate.py
├── train_lstm.py
├── requirements.txt
├── requirements-dl.txt
├── data/
│   └── news_dataset.csv
├── templates/
│   ├── index.html
│   └── about.html
└── static/
    └── style.css
```

## Important limitation
This is a learning/demo classifier, not a fact-checking tool. It predicts labels based on patterns in its training data and cannot determine whether an article is factually true. Replace the included sample data with a larger, carefully labeled dataset before making claims about real-world accuracy.
