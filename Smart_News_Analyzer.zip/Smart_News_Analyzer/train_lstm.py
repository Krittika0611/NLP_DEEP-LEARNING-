"""
Optional Deep Learning experiment: LSTM models for news category and sentiment.
Install requirements-dl.txt first. The bundled dataset is deliberately small for demonstration.
For meaningful results, replace it with a larger, balanced, labeled dataset.
"""
from pathlib import Path
import re
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout

ROOT = Path(__file__).parent
df = pd.read_csv(ROOT / "data" / "news_dataset.csv")

def clean(text):
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

df["text"] = df["text"].map(clean)
tokenizer = Tokenizer(num_words=5000, oov_token="<OOV>")
tokenizer.fit_on_texts(df["text"])
sequences = tokenizer.texts_to_sequences(df["text"])
X = pad_sequences(sequences, maxlen=60, padding="post", truncating="post")

for target in ["category", "sentiment"]:
    print(f"\nTraining LSTM for {target}...")
    encoder = LabelEncoder()
    y = encoder.fit_transform(df[target])
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = Sequential([
        Embedding(input_dim=5000, output_dim=64, mask_zero=True),
        LSTM(64, dropout=0.2),
        Dense(32, activation="relu"),
        Dropout(0.2),
        Dense(len(encoder.classes_), activation="softmax")
    ])
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.fit(X_train, y_train, validation_split=0.2, epochs=12, batch_size=8, verbose=1)
    loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test accuracy: {accuracy:.3f}")
    pred = model.predict(X_test, verbose=0).argmax(axis=1)
    print(classification_report(y_test, pred, target_names=encoder.classes_, zero_division=0))
    model.save(ROOT / f"lstm_{target}.keras")
    print(f"Saved {target} model.")
print("\nNote: The sample dataset is small; use a larger real-world dataset for meaningful performance.")
