"""Train/evaluate TF-IDF baseline models on the included sample dataset."""
from pathlib import Path
import re
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

DATA = Path(__file__).parent / "data" / "news_dataset.csv"

def clean(text):
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

df = pd.read_csv(DATA)
df["text"] = df["text"].map(clean)

for target in ["category", "sentiment"]:
    print(f"\n{'='*18} {target.upper()} {'='*18}")
    x_train, x_test, y_train, y_test = train_test_split(
        df["text"], df[target], test_size=0.25, random_state=42, stratify=df[target]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    model.fit(x_train, y_train)
    predictions = model.predict(x_test)
    print("Accuracy:", round(accuracy_score(y_test, predictions), 3))
    print(classification_report(y_test, predictions, zero_division=0))
    print("Note: dataset is small and educational; results are not representative of real news.")
