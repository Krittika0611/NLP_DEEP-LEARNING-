from pathlib import Path
import re
import joblib
import pandas as pd
from flask import Flask, render_template, request
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "news_dataset.csv"
MODEL_PATH = BASE_DIR / "news_models.joblib"

app = Flask(__name__)

def clean_text(text):
    """Basic NLP preprocessing: lowercase and remove URLs/symbols."""
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def train_models():
    data = pd.read_csv(DATA_PATH).dropna(subset=["text", "category", "sentiment"])
    data["text"] = data["text"].astype(str).map(clean_text)

    category_model = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=6000)),
        ("classifier", LogisticRegression(max_iter=1200, class_weight="balanced"))
    ])
    sentiment_model = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=6000)),
        ("classifier", LogisticRegression(max_iter=1200, class_weight="balanced"))
    ])

    category_model.fit(data["text"], data["category"])
    sentiment_model.fit(data["text"], data["sentiment"])
    joblib.dump({"category": category_model, "sentiment": sentiment_model}, MODEL_PATH)
    return category_model, sentiment_model

def get_models():
    if MODEL_PATH.exists():
        try:
            return joblib.load(MODEL_PATH)
        except Exception:
            pass
    category_model, sentiment_model = train_models()
    return {"category": category_model, "sentiment": sentiment_model}

models = get_models()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    article = ""
    if request.method == "POST":
        article = request.form.get("article", "").strip()
        if len(article.split()) < 3:
            result = {"error": "Please enter at least 3 words so the model has text to analyze."}
        else:
            cleaned = clean_text(article)
            category_model = models["category"]
            sentiment_model = models["sentiment"]

            category = category_model.predict([cleaned])[0]
            sentiment = sentiment_model.predict([cleaned])[0]
            cat_probs = category_model.predict_proba([cleaned])[0]
            sent_probs = sentiment_model.predict_proba([cleaned])[0]
            category_confidence = round(float(max(cat_probs)) * 100, 1)
            sentiment_confidence = round(float(max(sent_probs)) * 100, 1)

            # Highlight high-weight terms from the category TF-IDF vocabulary.
            vectorizer = category_model.named_steps["tfidf"]
            classifier = category_model.named_steps["classifier"]
            vec = vectorizer.transform([cleaned])
            feature_names = vectorizer.get_feature_names_out()
            nonzero = vec.nonzero()[1]
            keywords = sorted(
                [(feature_names[i], float(vec[0, i])) for i in nonzero],
                key=lambda item: item[1], reverse=True
            )[:8]

            result = {
                "category": category,
                "sentiment": sentiment,
                "category_confidence": category_confidence,
                "sentiment_confidence": sentiment_confidence,
                "keywords": [word for word, _ in keywords]
            }
    return render_template("index.html", result=result, article=article)

@app.route("/about")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    app.run(debug=True)
